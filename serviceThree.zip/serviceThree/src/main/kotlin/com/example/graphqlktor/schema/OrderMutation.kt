package com.example.graphqlktor.schema

import com.example.graphqlktor.services.OrderService
import org.jetbrains.exposed.sql.transactions.transaction
import java.math.BigDecimal
import java.time.LocalDateTime

class OrderMutation(private val orderService: OrderService) {
    fun createOrder(userId: Int, product: String, quantity: Int, price: BigDecimal, orderDate: LocalDateTime) =
      transaction {
          orderService.createOrder(userId, product, quantity, price, orderDate).toDTO()
      }
    fun deleteOrder(id: Int) =
        transaction {   orderService.deleteOrder(id)
}}

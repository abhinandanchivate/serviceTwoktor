package com.example.graphqlktor.services

import com.example.graphqlktor.models.Order
import com.example.graphqlktor.repository.OrderRepository
import org.jetbrains.exposed.sql.transactions.transaction
import java.math.BigDecimal
import java.time.LocalDateTime

class OrderService(private val repository: OrderRepository) {
    fun getOrder(id: Int): Order? = transaction {   repository.findById(id)}
    fun getOrdersByUserId(userId: Int): List<Order> = transaction {   repository.findByUserId(userId)}
    fun getAllOrders(): List<Order> = transaction {   repository.findAll()}
    
    fun createOrder(userId: Int, product: String, quantity: Int, price: BigDecimal, orderDate: LocalDateTime): Order {
        return transaction {   repository.save(Order.new {
            this.userId = userId
            this.product = product
            this.quantity = quantity
            this.price = price
            this.orderDate = orderDate
        })}
    }

    fun deleteOrder(id: Int): Boolean = transaction {   repository.delete(id)}
}

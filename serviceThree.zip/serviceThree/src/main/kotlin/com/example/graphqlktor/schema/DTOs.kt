package com.example.graphqlktor.schema

import com.example.graphqlktor.models.Order
import com.example.graphqlktor.models.Orders
import com.expediagroup.graphql.generator.annotations.GraphQLType
import com.expediagroup.graphql.generator.federation.directives.*
import java.math.BigDecimal
import java.time.LocalDate
import java.time.LocalDateTime

@KeyDirective(fields = FieldSet("id"))
data class OrderDTO(
    val id: Int,
    val userId: Int,
    val product: String,
    val quantity: Int,
    @GraphQLType(typeName = "BigDecimal")
    val price: BigDecimal,

    val orderDate: LocalDateTime,

)

fun Order.toDTO() = OrderDTO(
    id.value,
    userId,
    product,
    quantity,
    price,
    orderDate,

)



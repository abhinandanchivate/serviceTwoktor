package com.example.graphqlktor.schema

import com.example.graphqlktor.services.OrderService
import org.jetbrains.exposed.sql.transactions.transaction

class OrderQuery(private val orderService: OrderService) {
    fun getOrder(id: Int) = transaction{ orderService.getOrder(id)?.toDTO()  }
    fun getOrdersByUser(userId: Int) = transaction {   orderService.getOrdersByUserId(userId).map { it.toDTO() }}
    fun getAllOrders() = transaction {   orderService.getAllOrders().map { it.toDTO() }}
}

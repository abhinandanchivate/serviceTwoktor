package com.example.graphqlktor.repository

import com.example.graphqlktor.models.Order
import com.example.graphqlktor.models.Orders
import org.jetbrains.exposed.sql.transactions.transaction

class OrderRepository {
    fun findById(id: Int): Order? = transaction { Order.findById(id) }
    fun findByUserId(userId: Int): List<Order> = transaction { Order.find { Orders.userId eq userId }.toList() }
    fun findAll(): List<Order> = transaction { Order.all().toList() }
    fun save(order: Order): Order = transaction { order }
    fun delete(id: Int): Boolean = transaction {
        Order.findById(id)?.delete()?.let { true } ?: false
    }
}

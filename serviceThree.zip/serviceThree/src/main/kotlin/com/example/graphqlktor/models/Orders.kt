package com.example.graphqlktor.models

import org.jetbrains.exposed.dao.*
import org.jetbrains.exposed.dao.id.EntityID
import org.jetbrains.exposed.dao.id.IntIdTable
import org.jetbrains.exposed.sql.Column
import org.jetbrains.exposed.sql.javatime.datetime
import java.math.BigDecimal
import java.time.LocalDate
import java.time.LocalDateTime

object Orders : IntIdTable() {
    val userId: Column<Int> = integer("user_id").index()
    val product: Column<String> = varchar("product", 255)
    val quantity: Column<Int> = integer("quantity")
    val price: Column<BigDecimal> = decimal("price", 10, 2)
    val orderDate: Column<LocalDateTime> = datetime("order_date").default(LocalDateTime.now())
}

class Order(id: EntityID<Int>) : IntEntity(id) {
    companion object : IntEntityClass<Order>(Orders)
    var userId by Orders.userId
    var product by Orders.product
    var quantity by Orders.quantity
    var price by Orders.price
    var orderDate by Orders.orderDate
}

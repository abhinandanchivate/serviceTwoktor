package com.example.graphqlktor.repository

import com.example.graphqlktor.com.example.graphqlktor.models.User
import com.example.graphqlktor.com.example.graphqlktor.models.Users
import com.example.graphqlktor.com.example.graphqlktor.repository.UserRepository

import io.kotest.core.spec.style.StringSpec
import io.kotest.matchers.shouldBe
import io.kotest.matchers.shouldNotBe
import io.kotest.matchers.nulls.shouldBeNull
import org.jetbrains.exposed.sql.*
import org.jetbrains.exposed.sql.transactions.transaction
import java.time.LocalDateTime

class UserRepositoryTest2 : StringSpec({

    // Setup PostgreSQL database connection
    Database.connect(
        url = "jdbc:postgresql://localhost:5432/testdb",
        driver = "org.postgresql.Driver",
        user = "root",
        password = "root"
    )

    beforeTest {
        transaction {
            SchemaUtils.create(Users)
            Users.deleteAll()  // Clean up before each test
            Users.insert {
                it[name] = "Test User"
                it[email] = "testuser@example.com"
                it[age] = 30
                it[address] = "123 Test St"
                it[phoneNumber] = "1234567890"
                it[isActive] = true
                it[createdAt] = LocalDateTime.now()
            }
        }
    }

    afterTest {
        transaction {
            SchemaUtils.drop(Users)
        }
    }

    val userRepository = UserRepository()

    // Positive Test Cases

    "should find a user by valid id" {
        val user = transaction { User.find { Users.email eq "testuser@example.com" }.firstOrNull() }
        user shouldNotBe null
        val foundUser = user?.id?.value?.let { userRepository.findById(it) }
        foundUser shouldNotBe null
        foundUser?.email shouldBe "testuser@example.com"
        foundUser?.age shouldBe 30
        foundUser?.address shouldBe "123 Test St"
        foundUser?.phoneNumber shouldBe "1234567890"
        foundUser?.isActive shouldBe true
    }

    "should find all users" {
        val users = userRepository.findAll()
        users.size shouldBe 1
        users.first().email shouldBe "testuser@example.com"
    }

    "should save a new user" {
        transaction {
            val newUser = User.new {
                name = "New User"
                email = "newuser@example.com"
                age = 25
                address = "456 New Ave"
                phoneNumber = "0987654321"
                isActive = false
                createdAt = LocalDateTime.now()
            }
            userRepository.save(newUser)
        }

        val users = userRepository.findAll()
        users.size shouldBe 2
        users.any { it.email == "newuser@example.com" } shouldBe true
    }

    "should delete an existing user by id" {
        val user = transaction { User.find { Users.email eq "testuser@example.com" }.firstOrNull() }
        user shouldNotBe null
        val deleted = user?.id?.value?.let { userRepository.delete(it) }
        deleted shouldBe true

        val foundUser = user?.id?.value?.let { userRepository.findById(it) }
        foundUser.shouldBeNull()
    }

    // Negative Test Cases (Expecting Graceful Handling)

    "should return null when finding a user by non-existing id" {
        val nonExistentUser = userRepository.findById(999)
        nonExistentUser.shouldBeNull() // Expecting a null result for a non-existent user
    }

    "should return an empty list when no users exist" {
        transaction {
            Users.deleteAll()  // Clearing all records to check empty list case
        }
        val users = userRepository.findAll()
        users.size shouldBe 0  // Expecting an empty list
    }

    "should return false when deleting a non-existing user" {
        val deleted = userRepository.delete(999)
        deleted shouldBe false // Expecting delete to return false gracefully
    }

    "should handle duplicate email insertion gracefully" {
        val duplicateUserAttempt = try {
            transaction {
                User.new {
                    name = "Duplicate User"
                    email = "testuser@example.com"  // Trying to insert duplicate email
                    age = 35
                    address = "789 Dup St"
                    phoneNumber = "1122334455"
                    isActive = true
                    createdAt = LocalDateTime.now()
                }
            }
            false // If insertion succeeds, test should fail
        } catch (e: Exception) {
            true // Expecting an exception
        }
        duplicateUserAttempt shouldBe true // Test should pass because it caught the exception
    }

})

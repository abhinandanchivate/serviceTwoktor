import io.kotest.core.spec.style.StringSpec
import io.kotest.matchers.shouldBe
import io.mockk.every
import io.mockk.mockk

class MockingTest : StringSpec({
    "should return mocked data" {
        val service = mockk<MyService>()
        every { service.getData() } returns "Mocked Data"

        service.getData() shouldBe "Mocked Data"
    }
})

interface MyService {
    fun getData(): String
}

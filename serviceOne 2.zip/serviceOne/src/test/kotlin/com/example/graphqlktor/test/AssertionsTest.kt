package com.example.graphqlktor.test

import io.kotest.core.spec.style.StringSpec
import io.kotest.matchers.collections.shouldContainExactly
import io.kotest.matchers.string.shouldStartWith

class AssertionsTest : StringSpec({
    "list should contain exactly specified elements" {
        val list = listOf(1, 2, 3)
        list shouldContainExactly listOf(1, 2, 3)
    }

    "string should start with specified prefix" {
        "Kotest Framework" shouldStartWith "Kotest"
    }
})

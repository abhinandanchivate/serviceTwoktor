package com.example.graphqlktor.repository

import com.example.graphqlktor.com.example.graphqlktor.models.User
import com.example.graphqlktor.com.example.graphqlktor.models.Users
import com.example.graphqlktor.com.example.graphqlktor.repository.UserRepository
import com.example.graphqlktor.models.connectToDatabase

import io.kotest.core.spec.style.StringSpec
import io.kotest.matchers.collections.shouldContain
import io.kotest.matchers.shouldBe
import org.jetbrains.exposed.dao.with
import org.jetbrains.exposed.sql.Database
import org.jetbrains.exposed.sql.SchemaUtils
import org.jetbrains.exposed.sql.transactions.transaction

class UserRepositoryTest : StringSpec({

    val db = connectToDatabase()

    beforeTest {
        transaction(db) {
            SchemaUtils.create(Users)
        }
    }

    afterTest {
        transaction(db) {
            SchemaUtils.drop(Users)
        }
    }

    "should save a user and find by ID" {
        transaction {
            val user = User.new {
                name = "John Doe"
                email = "johndoe@example.com"
                age = 30
                address = "123 Main St"
                phoneNumber = "1234567890"
                isActive = true
            }
            val repository = UserRepository()
            repository.save(user)
            val foundUser = repository.findById(user.id.value)
            foundUser?.name shouldBe "John Doe"
            foundUser?.email shouldBe "johndoe@example.com"
        }
    }

    "should find all users" {
        transaction {
            User.new {
                name = "Alice"
                email = "alice@example.com"
                age = 25
                address = "456 Another St"
                phoneNumber = "9876543210"
                isActive = true
            }
            User.new {
                name = "Bob"
                email = "bob@example.com"
                age = 35
                address = "789 Some Ave"
                phoneNumber = "5551234567"
                isActive = false
            }
            val repository = UserRepository()
            val users = repository.findAll()
            users.map { it.name } shouldContain "Alice"
            users.map { it.name } shouldContain "Bob"
        }
    }

    "should delete a user" {
        transaction {
            val user = User.new {
                name = "Charlie"
                email = "charlie@example.com"
                age = 28
                address = "111 Random St"
                phoneNumber = "6667778888"
                isActive = true
            }
            val repository = UserRepository()
            repository.delete(user.id.value) shouldBe true
            println( "value "+repository.findById(user.id.value))
            repository.findById(user.id.value) shouldBe null
        }
    }
})

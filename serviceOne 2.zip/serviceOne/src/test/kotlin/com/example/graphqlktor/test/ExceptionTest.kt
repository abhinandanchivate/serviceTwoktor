package com.example.graphqlktor.test

import io.kotest.core.spec.style.StringSpec
import io.kotest.assertions.throwables.shouldThrow

class ExceptionTest : StringSpec({
    "should throw an exception" {
        shouldThrow<IllegalArgumentException> {
            throw IllegalArgumentException("Invalid argument")
        }
    }
})

package com.example.graphqlktor.test

import io.kotest.core.spec.style.ShouldSpec
import io.kotest.matchers.string.shouldContain

class ExampleShouldSpec : ShouldSpec({
    should("verify string content") {
        val text = "Kotlin Testing"
        text shouldContain "Testing"
    }
})

package com.example.graphqlktor.services

import com.example.graphqlktor.com.example.graphqlktor.models.User
import com.example.graphqlktor.com.example.graphqlktor.models.Users
import com.example.graphqlktor.com.example.graphqlktor.repository.UserRepository
import com.example.graphqlktor.com.example.graphqlktor.services.UserService
import io.kotest.core.spec.style.StringSpec
import io.kotest.matchers.shouldBe
import io.kotest.matchers.shouldNotBe
import io.kotest.matchers.nulls.shouldBeNull
import io.mockk.every
import io.mockk.mockk
import io.mockk.verify
import org.jetbrains.exposed.sql.Database
import org.jetbrains.exposed.sql.SchemaUtils
import org.jetbrains.exposed.sql.transactions.transaction

class UserServiceTest : StringSpec({

    beforeSpec {
        Database.connect(
            url = "jdbc:postgresql://localhost:5432/testdb",
            driver = "org.postgresql.Driver",
            user = "root",
            password = "root"
        )

        transaction {
            SchemaUtils.create(Users)
        }
    }

    afterSpec {
        transaction {
            SchemaUtils.drop(Users)
        }
    }

    val mockRepository = mockk<UserRepository>(relaxed = true)
    // it means that the mock object will return default values for all functiuon calls without requiring explict behavior to be specifed
    //
    val userService = UserService(mockRepository)

    "should return user by valid id" {
        val mockUser = transaction {
            User.new {
                name = "Mock User"
                email = "mockuser4@example.com"
                age = 28
                address = "Mock Address"
                phoneNumber = "1234567890"
                isActive = true
            }
        }

        every { mockRepository.findById(mockUser.id.value) } returns mockUser

        val result = transaction { userService.getUser(mockUser.id.value) }

        result shouldNotBe null
        result?.email shouldBe "mockuser4@example.com"

        verify { mockRepository.findById(mockUser.id.value) }
    }

    "should return null when getting a non-existing user by id" {
       // every { mockRepository.findById(999) } returns null

        val result = transaction { userService.getUser(999) }

        println(result.toString())
        result.shouldBeNull()

      //  verify { mockRepository.findById(999) }
    }

    "should create a new user" {
        val newUser = transaction {
            User.new {
                name = "New User"
                email = "newuser7@example.com"
                age = 25
                address = "456 New Ave"
                phoneNumber = "0987654321"
                isActive = false
            }
        }

        every { mockRepository.save(any()) } returns newUser

        val result = transaction {
            userService.createUser(
                name = "New User",
                email = "newuser9@example.com",
                age = 25,
                address = "456 New Ave",
                phoneNumber = "0987654321",
                isActive = false
            )
        }

        result shouldNotBe null
        result.name shouldBe "New User"
        result.email shouldBe "newuser7@example.com"

        verify { mockRepository.save(any()) }
    }

    "should delete an existing user" {
        val mockUser = transaction {
            User.new {
                name = "Mock User"
                email = "mockuser@example.com"
                age = 28
                address = "Mock Address"
                phoneNumber = "1234567890"
                isActive = true
            }
        }

        every { mockRepository.delete(mockUser.id.value) } returns true

        val result = transaction { userService.deleteUser(mockUser.id.value) }

        result shouldBe true

        verify { mockRepository.delete(mockUser.id.value) }
    }

    "should return false when deleting a non-existing user" {
        every { mockRepository.delete(999) } returns false

        val result = transaction { userService.deleteUser(999) }

        result shouldBe false

        verify { mockRepository.delete(999) }
    }
})

package com.example.graphqlktor.services

import com.example.graphqlktor.com.example.graphqlktor.services.UserService

//package com.example.graphqlktor.services
//
//import com.example.graphqlktor.com.example.graphqlktor.models.User
//import com.example.graphqlktor.com.example.graphqlktor.models.Users
//import com.example.graphqlktor.com.example.graphqlktor.repository.UserRepository
//import com.example.graphqlktor.com.example.graphqlktor.services.UserService
//import io.kotest.core.spec.style.StringSpec
//import io.kotest.matchers.shouldBe
//import io.kotest.matchers.shouldNotBe
//import io.kotest.matchers.nulls.shouldBeNull
//import org.jetbrains.exposed.sql.*
//import org.jetbrains.exposed.sql.transactions.transaction
//import java.time.LocalDateTime
//
//class UserServiceTest : StringSpec({
//
//    // Setup PostgreSQL database connection
//    Database.connect(
//        url = "jdbc:postgresql://localhost:5432/testdb",
//        driver = "org.postgresql.Driver",
//        user = "root",
//        password = "root"
//    )
//
//    beforeTest {
//        transaction {
//            SchemaUtils.create(Users)
//            Users.deleteAll()  // Clean up before each test
//            Users.insert {
//                it[name] = "Test User"
//                it[email] = "testuser@example.com"
//                it[age] = 30
//                it[address] = "123 Test St"
//                it[phoneNumber] = "1234567890"
//                it[isActive] = true
//                it[createdAt] = LocalDateTime.now()
//            }
//        }
//    }
//
//    afterTest {
//        transaction {
//            SchemaUtils.drop(Users)
//        }
//    }
//
//    val userRepository = UserRepository()
//    val userService = UserService(userRepository)
//
//    // Positive Test Cases
//
//    "should return user by valid id" {
//        val existingUser = transaction { User.find { Users.email eq "testuser@example.com" }.firstOrNull() }
//        existingUser shouldNotBe null
//
//        val foundUser = userService.getUser(existingUser!!.id.value)
//        foundUser shouldNotBe null
//        foundUser?.email shouldBe "testuser@example.com"
//    }
//
//    "should return all users" {
//        val users = userService.getAllUsers()
//        users.size shouldBe 1
//        users.first().email shouldBe "testuser@example.com"
//    }
//
//    "should create a new user" {
//        val newUser = userService.createUser(
//            name = "New User",
//            email = "newuser@example.com",
//            age = 25,
//            address = "456 New Ave",
//            phoneNumber = "0987654321",
//            isActive = false
//        )
//
//        newUser shouldNotBe null
//        newUser.name shouldBe "New User"
//        newUser.email shouldBe "newuser@example.com"
//
//        val foundUser = userService.getUser(newUser.id.value)
//        foundUser shouldNotBe null
//        foundUser?.email shouldBe "newuser@example.com"
//    }
//
//    "should delete an existing user" {
//        val existingUser = transaction { User.find { Users.email eq "testuser@example.com" }.firstOrNull() }
//        existingUser shouldNotBe null
//
//        val deleted = userService.deleteUser(existingUser!!.id.value)
//        deleted shouldBe true
//
//        val foundUser = userService.getUser(existingUser.id.value)
//        foundUser.shouldBeNull()
//    }
//
//    // Negative Test Cases (Expecting Graceful Handling)
//
//    "should return null when getting a non-existing user by id" {
//        val nonExistentUser = userService.getUser(999)
//        nonExistentUser.shouldBeNull()  // Expecting null result
//    }
//
//    "should return an empty list when no users exist" {
//        transaction { Users.deleteAll() }  // Clear users table
//
//        val users = userService.getAllUsers()
//        users.size shouldBe 0  // Expecting an empty list
//    }
//
//    "should return false when deleting a non-existing user" {
//        val deleted = userService.deleteUser(999)
//        deleted shouldBe false  // Expecting deletion to fail gracefully
//    }
//
//    "should throw an exception when trying to create a user with duplicate email" {
//        val duplicateUserAttempt = try {
//            userService.createUser(
//                name = "Duplicate User",
//                email = "testuser@example.com",  // Duplicate email
//                age = 35,
//                address = "789 Dup St",
//                phoneNumber = "1122334455",
//                isActive = true
//            )
//            false // If it succeeds, test should fail
//        } catch (e: Exception) {
//            true // Expecting an exception
//        }
//        duplicateUserAttempt shouldBe true // Test should pass because it caught the exception
//    }
//
//})





import com.example.graphqlktor.com.example.graphqlktor.models.User
import com.example.graphqlktor.com.example.graphqlktor.models.Users
import com.example.graphqlktor.com.example.graphqlktor.repository.UserRepository
import io.kotest.core.spec.style.StringSpec
import io.kotest.matchers.shouldBe
import io.kotest.matchers.shouldNotBe
import io.kotest.matchers.nulls.shouldBeNull
import io.mockk.every
import io.mockk.mockk
import io.mockk.verify
import org.jetbrains.exposed.dao.id.EntityID

//class UserServiceTest : StringSpec({
//
//    // Mock the UserRepository
//    val mockRepository = mockk<UserRepository>()
//
//    // Create the UserService with the mocked repository
//    val userService = UserService(mockRepository)
//
//    // Sample User data for tests
//    val sampleUser = com.example.graphqlktor.com.example.graphqlktor.models.Users(
//        id = EntityID(1, User.table),
//        name = "Test User",
//        email = "testuser@example.com",
//        age = 30,
//        address = "123 Test St",
//        phoneNumber = "1234567890",
//        isActive = true
//    )
//
//    "should return a user by valid id" {
//        every { mockRepository.findById(1) } returns sampleUser
//
//        val result = userService.getUser(1)
//
//        result shouldNotBe null
//        result?.email shouldBe "testuser@example.com"
//
//        verify { mockRepository.findById(1) }
//    }
//
//    "should return all users" {
//        val mockUsers = listOf(sampleUser)
//
//        every { mockRepository.findAll() } returns mockUsers
//
//        val result = userService.getAllUsers()
//
//        result.size shouldBe 1
//        result.first().email shouldBe "testuser@example.com"
//
//        verify { mockRepository.findAll() }
//    }
//
//    "should create a new user" {
//        every { mockRepository.save(any()) } answers { firstArg() }
//
//        val newUser = userService.createUser(
//            name = "New User",
//            email = "newuser@example.com",
//            age = 25,
//            address = "456 New Ave",
//            phoneNumber = "0987654321",
//            isActive = false
//        )
//
//        newUser shouldNotBe null
//        newUser.name shouldBe "New User"
//        newUser.email shouldBe "newuser@example.com"
//
//        verify { mockRepository.save(any()) }
//    }
//
//    "should return true when deleting an existing user" {
//        every { mockRepository.delete(1) } returns true
//
//        val result = userService.deleteUser(1)
//
//        result shouldBe true
//
//        verify { mockRepository.delete(1) }
//    }
//
//    "should return false when deleting a non-existing user" {
//        every { mockRepository.delete(999) } returns false
//
//        val result = userService.deleteUser(999)
//
//        result shouldBe false
//
//        verify { mockRepository.delete(999) }
//    }
//
//    "should return null when getting a non-existing user by id" {
//        every { mockRepository.findById(999) } returns null
//
//        val result = userService.getUser(999)
//
//        result.shouldBeNull()
//
//        verify { mockRepository.findById(999) }
//    }
//})


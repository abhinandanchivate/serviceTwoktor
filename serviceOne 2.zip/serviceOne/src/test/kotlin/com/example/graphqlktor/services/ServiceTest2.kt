package com.example.graphqlktor.services

import io.kotest.core.spec.style.StringSpec
import io.kotest.matchers.shouldBe
import io.mockk.*
import kotlinx.coroutines.runBlocking

// Service to be tested
class UserService(private val repository: UserRepository) {
    fun getUser(id: Int): String {
        return repository.findUserById(id) ?: "User Not Found"
    }

    fun deleteUser(id: Int) {
        repository.removeUserById(id)
    }

    suspend fun addUser(name: String) {
        repository.saveUser(name)
    }
}

// Mocked repository interface
interface UserRepository {
    fun findUserById(id: Int): String?
    suspend fun saveUser(name: String)
    fun removeUserById(id: Int)

}

// Kotest test cases with advanced MockK usage
class UserServiceTest2 : StringSpec({

    val repository = mockk<UserRepository>()
    val service = UserService(repository)

    "should return user when found" {
        every { repository.findUserById(1) } returns "Alice"

        val result = service.getUser(1)

        result shouldBe "Alice"
        verify(exactly = 1) { repository.findUserById(1) }
    }

    "should return default when user not found" {
        every { repository.findUserById(2) } returns null

        val result = service.getUser(2)

        result shouldBe "User Not Found"
        verify { repository.findUserById(2) }
        // checks if the method was called with expected arg or not.
    }

    "should capture arguments when adding user" {
        coEvery { repository.saveUser(any()) } just Runs

// set up the mock to allow the saveUser function to be caled without actually performing any operations.
        // it will not return anything.

        runBlocking {
            service.addUser("Bob")
        }

        val slot = slot<String>()
        // slot is used to capture the data / value provided to the method call.

        coVerify { repository.saveUser(capture(slot)) }
        slot.captured shouldBe "Bob"
    }

    "should verify order of function calls" {
        every { repository.findUserById(1) } returns "Alice"
        every { repository.findUserById(2) } returns "Bob"

        service.getUser(1)
        service.getUser(2)

        verifyAll {
            repository.findUserById(2)
            repository.findUserById(1)
        }
    }

    "should verify void method call" {
        // Mock the repository
        val repository = mockk<UserRepository>()

        // Stub the void method to do nothing
        every { repository.removeUserById(any()) } just Runs

        val service = UserService(repository)

        // Call the method
        service.deleteUser(42)

        // Verify that removeUserById was called with argument 42
        verify { repository.removeUserById(42) }
    }

    "should verify no interactions" {
        verify(exactly = 0) { repository.findUserById(any()) }
    }
})

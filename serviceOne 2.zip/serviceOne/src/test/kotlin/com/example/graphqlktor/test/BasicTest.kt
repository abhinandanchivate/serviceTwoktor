package com.example.graphqlktor.test

import io.kotest.core.spec.style.StringSpec
import io.kotest.matchers.shouldBe

class BasicTest : StringSpec({
    "should sum of two numbers should be correct" {
        val sum = 3 + 5
        sum shouldBe 8
    }

    "string length should be as expected" {
        val str = "Kotest"
        str.length shouldBe 6
    }
})

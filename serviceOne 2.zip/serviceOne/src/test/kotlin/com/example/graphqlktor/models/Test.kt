package com.example.graphqlktor.models



import io.kotest.core.spec.style.StringSpec
import io.kotest.matchers.shouldBe
import io.kotest.matchers.shouldNotBe
import io.kotest.matchers.string.shouldContain
import org.jetbrains.exposed.sql.Database
import org.postgresql.util.PSQLException
import org.postgresql.util.PSQLState

fun connectToDatabase(): Database? {
    return try {
        Database.connect(
            url = "jdbc:postgresql://localhost:5432/users",
            driver = "org.postgresql.Driver",
            user = "root",
            password = "root"
        )
    } catch (e: Exception) {
        null
    }
}

class DatabaseConfigTest : StringSpec({

    beforeSpec {
        System.setProperty("jdk.instrument.traceUsage", "true")
        System.setProperty("bytebuddy.agent.suppress", "true")
    }

    "should successfully connect to the database with correct credentials" {
        val db = connectToDatabase()
        db shouldNotBe null
        db?.let {
            it.vendor shouldBe "PostgreSQL"
            it.url shouldContain "localhost:5432/users"
        }
    }

    "should return null when database connection fails" {
        val invalidDb = try {
            Database.connect(
                url = "jdbc:postgresql://localhost:5432/users",
                driver = "org.postgresql.Driver",
                user = "wrongUser",
                password = "wrongPassword"
            )
            null // Connection should fail, so explicitly set to null
        } catch (e: PSQLException) {
            e.sqlState shouldBe PSQLState.CONNECTION_REJECTED.state
            null
        }
        invalidDb shouldBe null
    }

})

package com.example.graphqlktor.com.example.graphqlktor.schema

import com.example.graphqlktor.com.example.graphqlktor.models.User
import com.expediagroup.graphql.generator.annotations.GraphQLType
import com.expediagroup.graphql.generator.federation.directives.FieldSet
import com.expediagroup.graphql.generator.federation.directives.KeyDirective
import com.expediagroup.graphql.generator.federation.directives.ShareableDirective
import java.time.LocalDate
import java.time.LocalDateTime

@KeyDirective(FieldSet("id"))
data class UserDTO(
    val id: Int,
    @ShareableDirective
    val name: String,
    @ShareableDirective
    val email: String,
    @ShareableDirective
    val age: Int,
    @ShareableDirective
    val address: String,
    @ShareableDirective
    val phoneNumber: String,
    @ShareableDirective
    val isActive: Boolean,
  //  @GraphQLType(name = "LocalDate")
    @ShareableDirective
    val createdDate: LocalDate,
    @ShareableDirective
  //  @GraphQLType(name = "LocalDateTime")
    val updatedDateTime: LocalDateTime
)

fun User.toDTO() = UserDTO(
    id.value,
    name,
    email,
    age,
    address,
    phoneNumber,
    isActive,
    LocalDate.now(),  // Example placeholder
    LocalDateTime.now() // Example placeholder
)


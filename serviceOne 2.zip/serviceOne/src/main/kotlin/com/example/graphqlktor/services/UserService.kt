package com.example.graphqlktor.com.example.graphqlktor.services

import com.example.graphqlktor.com.example.graphqlktor.models.User
import com.example.graphqlktor.com.example.graphqlktor.repository.UserRepository


class UserService(private val repository: UserRepository) {
    fun getUser(id: Int): User?
        {
        println("inside the get user ")
        return repository.findById(id)}
    fun getAllUsers(): List<User> = repository.findAll()
    fun createUser(name: String, email: String, age: Int, address: String, phoneNumber: String, isActive: Boolean): User {
      println("hello from service ")
        return repository.save(User.new {
            this.name = name
            this.email = email
            this.age = age
            this.address = address
            this.phoneNumber = phoneNumber
            this.isActive = isActive
        })

    }
    fun deleteUser(id: Int): Boolean = repository.delete(id)
}

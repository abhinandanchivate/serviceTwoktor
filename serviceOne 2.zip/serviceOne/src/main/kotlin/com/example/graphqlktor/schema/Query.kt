package com.example.graphqlktor.com.example.graphqlktor.schema
import org.jetbrains.exposed.sql.transactions.transaction
import com.example.graphqlktor.com.example.graphqlktor.services.UserService


class UserQuery(private val userService: UserService) {
    fun userById(id: Int) = transaction{ userService.getUser(id)?.toDTO()}
    fun getAllUsers() = userService.getAllUsers().map { it.toDTO() }
}

package com.example.graphqlktor.com.example.graphqlktor.schema

import org.jetbrains.exposed.sql.transactions.transaction
import com.example.graphqlktor.com.example.graphqlktor.services.UserService


class Mutation(private val userService: UserService) {
    fun createUser(name: String, email: String, age: Int, address: String, phoneNumber: String, isActive: Boolean) =
      transaction {
          userService.createUser(name, email, age, address, phoneNumber, isActive).toDTO()
      }
    fun deleteUser(id: Int) = transaction {
        userService.deleteUser(id)
    }}

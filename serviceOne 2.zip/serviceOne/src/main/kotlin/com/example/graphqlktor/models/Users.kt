
package com.example.graphqlktor.com.example.graphqlktor.models
import org.jetbrains.exposed.dao.*
import org.jetbrains.exposed.dao.id.*
import org.jetbrains.exposed.sql.*
import org.jetbrains.exposed.sql.javatime.datetime
import java.time.LocalDateTime

object Users : IntIdTable() {
    val name = varchar("name", 255)
    val email = varchar("email", 255).uniqueIndex()
    val age = integer("age")
    val address = varchar("address", 255)
    val phoneNumber = varchar("phone_number", 15)
    val isActive = bool("is_active")
    val createdAt: Column<LocalDateTime> = datetime("created_at").default(LocalDateTime.now())

}


class User(id: EntityID<Int>) : IntEntity(id) {
    companion object : IntEntityClass<User>(Users)
    var name by Users.name
    var email by Users.email
    var age by Users.age
    var address by Users.address
    var phoneNumber by Users.phoneNumber
    var isActive by Users.isActive
    var createdAt by Users.createdAt
}
package com.example.graphqlktor.com.example.graphqlktor.repository

import com.example.graphqlktor.com.example.graphqlktor.models.User
import org.jetbrains.exposed.sql.transactions.transaction

class UserRepository {
    fun findById(id: Int): User? = transaction {
        println("inside repo")
        return@transaction User.findById(id) }
    fun findAll(): List<User> = transaction { User.all().toList() }
    fun save(user: User): User = transaction { user }
    fun delete(id: Int): Boolean = transaction {
        User.findById(id)?.delete()?.let { true } ?: false
    }
}
